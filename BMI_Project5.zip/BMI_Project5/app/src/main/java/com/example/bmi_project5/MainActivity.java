/**
 * This class is the main activity that handles taking in the users height and weight and
 * also calculating the BMI.
 * @author Craig Natoli Shashwat Singh
 */
package com.example.bmi_project5;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.example.bmi_project5.R;

import java.text.DecimalFormat;


public class MainActivity extends AppCompatActivity {
    RadioButton radio1, radio2;
    EditText text1, text2,text3;
    Button button1, button2;
    double bmi;
    static final double AMERICAN_UNITS = 703;
    public static final String EXTRA_MESSAGE = "com.example.andriod.twoactivities.extra.MESSAGE";

    /**
     * This method is used to initialize the activity.
     * @param savedInstanceState opportunity to save any application state that you want to restore
     * @author Craig Natoli
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        radio1 = (RadioButton) findViewById(R.id.radio1);
        radio1.setChecked(true);
        radio2 = (RadioButton) findViewById(R.id.radio2);
        text1 = (EditText) findViewById(R.id.text1);
        text2 = (EditText) findViewById(R.id.text2);
        text3 = (EditText) findViewById(R.id.text3);
        button1 = (Button) findViewById(R.id.button1);
        button2 = (Button) findViewById(R.id.button2);

    }

    /**
     * Displays the correct hints when a radio button is checked.
     * @param view distinguishes which view on the layout has been selected
     * @author Craig Natoli
     */
    public void onRadioButtonClicked(View view) {
        if (radio1.isChecked()) {//checked the first radio button
            text1.getText().clear();
            text2.getText().clear();
            text3.getText().clear();
            text1.setHint("Enter weight in pounds");
            text2.setHint("Enter height in inches");
            bmi = 0;
        }
        if (radio2.isChecked()) {//checked second radio button
            text1.getText().clear();
            text2.getText().clear();
            text3.getText().clear();
            text1.setHint("Enter weight in kilograms");
            text2.setHint("Enter height in meters");
            bmi = 0;
        }
    }

    /**
     * Calculates the BMI in either metric or US units.
     * @param weight weight entered
     * @param height height entered
     * @return the calculated BMI values
     * @author Craig Natoli
     */
    private double calculations(double weight, double height){
        double bmi = 0;
        if(radio1.isChecked()){//first radio button checked
            bmi = (weight *AMERICAN_UNITS)/(height * height);
        }
        if(radio2.isChecked()){//second radio button checked
            bmi = weight/(height * height);
        }
        return bmi;
    }

    /**
     * Clears the editable text fields
     * @author Craig Natoli
     */
    private void clear(){
        text1.getText().clear();
        text2.getText().clear();
    }

    /**
     * Handles the errors that can occure with bad input or no input at all by the user.
     * @param weight entered by the user
     * @param height entered by the user
     * @return true if error has been detected else false
     * @author Craig Natoli
     */
    private boolean inputErrors(String weight,String height){
        if(TextUtils.isEmpty(height) && TextUtils.isEmpty(weight) == false && Double.compare(Double.parseDouble(weight),0) != 0){
            Toast.makeText(getApplicationContext(),"You must enter in a number for height",Toast.LENGTH_SHORT).show();
            return true;
        }
        if(TextUtils.isEmpty(height) && TextUtils.isEmpty(weight) == false && Double.compare(Double.parseDouble(weight),0) == 0){
            Toast.makeText(getApplicationContext(),"You must enter in a number for height and the weight entered must be greater than 0",Toast.LENGTH_SHORT).show();
            return true;
        }
        if(TextUtils.isEmpty(height) == false && TextUtils.isEmpty(weight) && Double.compare(Double.parseDouble(height),0) != 0){
            Toast.makeText(getApplicationContext(),"You must enter in a number for weight",Toast.LENGTH_SHORT).show();
            return true;
        }
        if(TextUtils.isEmpty(height) == false && TextUtils.isEmpty(weight) && Double.compare(Double.parseDouble(height),0) == 0){
            Toast.makeText(getApplicationContext(),"You must enter in a number for weight and the height entered must be greater than 0",Toast.LENGTH_SHORT).show();
            return true;
        }
        if(TextUtils.isEmpty(height) && TextUtils.isEmpty(weight)){
            Toast.makeText(getApplicationContext(),"You must enter in a number for weight and height",Toast.LENGTH_SHORT).show();
            return true;
        }
        if(TextUtils.isEmpty(height) == false && Double.parseDouble(weight) == 0 && Double.parseDouble(height) != 0){
            Toast.makeText(getApplicationContext(),"You must enter in a number greater than 0 for weight",Toast.LENGTH_SHORT).show();
            return true;
        }
        if(TextUtils.isEmpty(height) == false && Double.parseDouble(height) == 0 && Double.compare(Double.parseDouble(weight),0) !=0 ){
            Toast.makeText(getApplicationContext(),"You must enter in a number greater than 0 for height",Toast.LENGTH_SHORT).show();
            return true;
        }
        if( Double.compare(Double.parseDouble(weight),0) == 0 &&  Double.compare(Double.parseDouble(height),0) == 0){
            Toast.makeText(getApplicationContext(),"You must enter in a number greater than 0 for weight and height",Toast.LENGTH_SHORT).show();
            return true;
        }
        return false;
    }

    /**
     * Handles calculating the BMI when the calculate button has been clicked.
     * @param view distinguishes which view on the layout has been selected
     * @author Craig Natoli
     */
    @SuppressLint("DefaultLocale")
    public void onButtonClickedCalculate(View view) {
        String weight = text1.getText().toString();
        String height = text2.getText().toString();
        double heightNumber = 0;
        double weightNumber = 0;
        if(inputErrors(weight,height) != true){//checking that no errors have been entered
            heightNumber = Double.parseDouble(height);
            weightNumber = Double.parseDouble(weight);
            bmi = calculations(weightNumber,heightNumber);
            DecimalFormat df = new DecimalFormat("#.00");
            text3.setText(df.format(bmi));
            clear();
        }
    }

    /**
     * Handles opening up another activity to display the advice for the BMI
     * @param view distinguishes which view on the layout has been selected
     * @author Craig Natoli
     */
    public void onButtonClickedAdvice(View view) {
        if(bmi > 0) {// BMI greater than 0
            Intent intent = new Intent(this, Activity2.class);
            String message = String.format("%.2f",bmi);
            intent.putExtra(EXTRA_MESSAGE,message);
            startActivity(intent);
        }
        else{
            Toast.makeText(getApplicationContext(),"A BMI must be calculated first",Toast.LENGTH_SHORT).show();
        }
    }
}
