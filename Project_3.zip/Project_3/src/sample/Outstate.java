/**
 * This class is a subclass of Student that calculates, and implements
 * the correct tuition due for out of state students.
 * @author Craig Natoli Shashwat Singh
 */
package sample;
public class Outstate extends Student {
    private boolean tristate;
    //constants required for this class
    private static final int CREDIT = 756;
    private static final int PART_TIME = 846;
    private static final int FULL_TIME = 1441;
    private static final int CREDIT_NUM = 12;
    private static final int CREDIT_MAX = 15;

    /**
     * Parameterized constructor that fills parameters of the superclass
     * and sets the boolean value of tristate
     * @param fname first name of the student
     * @param lname last name of the student
     * @param credit number of credits
     * @param tristate status of being tri-state
     * @author Craig Natoli
     */
    public Outstate (String fname, String lname, int credit, boolean tristate){
        super(fname,lname,credit);
        this.tristate =  tristate;
    }
    /**
     * Establishes the out of state students information
     * @return String of out of state students information
     * @author Craig Natoli
     */
    @Override
    public String toString(){
        if(tristate == true) {
            return super.toString() + ", Status: Out-of-state" + ", TriState: True ";
        }
        else{
            return super.toString() + ", Status: Out-of-state" + ", TriState: False ";
        }
    }

    /**
     * Calculates the correct tuition due for an out of sate student based off if the
     * student is part-time, full-time, or an tri-state student.
     * @return the tuition amount due
     * @author Craig Natoli
     */
    @Override
    public int tuitionDue() {
        int total_due = 0;
        if((super.credit >= CREDIT_NUM && super.credit < CREDIT_MAX)  && tristate == true){
            total_due = super.credit * (CREDIT-200) + FULL_TIME ;
        }
        if(super.credit >= CREDIT_MAX  && tristate == true){
            total_due = CREDIT_MAX * (CREDIT - 200) + FULL_TIME ;
        }
        if((super.credit >= CREDIT_NUM && super.credit < CREDIT_MAX)  && tristate == false){
            total_due = super.credit * CREDIT + FULL_TIME ;
        }
        if(super.credit >= CREDIT_MAX  && tristate == false){
            total_due = CREDIT_MAX * CREDIT + FULL_TIME;
        }
        if(super.credit < CREDIT_NUM){
            total_due = super.credit * CREDIT + PART_TIME;
        }
        return total_due;
    }
    //Test Bed
    public static void main(String args[]){
        Outstate out = new Outstate("craig","natoli",11,true);
        Outstate out5 = new Outstate("craig","natoli",11,false);
        Outstate out1 = new Outstate("craig1","natoli",14,true);
        Outstate out2 = new Outstate("craig2","natoli",14,false);
        Outstate out3 = new Outstate("craig3","natoli",15,true);
        Outstate out4 = new Outstate("craig4","natoli",17,false);
        //Test Case 0
        System.out.println(out);
        //Test Case 1
        System.out.println(out5);
        //Test Case 2
        System.out.println(out.tuitionDue());
        //Test Case 3
        System.out.println(out1.tuitionDue());
        //Test Case 4
        System.out.println(out2.tuitionDue());
        //Test Case 5
        System.out.println(out3.tuitionDue());
        //Test Case 6
        System.out.println(out4.tuitionDue());
    }
}
