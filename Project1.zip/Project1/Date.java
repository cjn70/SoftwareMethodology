/**
    The Date class takes in either a String or a Date object and evaluates the date for correctness.
    Then evaluates the date if the date is valid or not or tests if date is equal to another date.
    @author Craig Natoli Shashwat Singh
 */
import java.util.*;
public class Date
{
   private int  day;
   private int  month;
   private int  year;

    /**
     * Tokenize String and creates a date object.
     * @param d of person entered
     * @author Shashwat Singh
     */
   public Date(String d)
   {
      StringTokenizer token = new StringTokenizer(d,"/");
      int token_counter = 0;
      int i = 0;
      String some = "";
      //Counting the number of / in the String to establish size of String array
      for(i =0; i < d.length(); i++){
   	   if(d.charAt(i) == '/'){
   		   token_counter ++;
   		  }
   	 }
      token_counter = (token_counter+1);
      String[] words = new String[token_counter];
      token_counter = 0;
      while(token.hasMoreTokens()){
   	    words[token_counter] = token.nextToken();
   		 token_counter ++;		 
       }
      month = Integer.parseInt(words[0]);
      day = Integer.parseInt(words[1]);
      year = Integer.parseInt(words[2]);
   }

    /**
     * Assigns the correct attributes of Date to the Date instance entered.
     * @param  d of person entered
     * @author Shashwat Singh
     */
   public Date(Date d)
   {
      this.day = d.day;
      this.month = d.month;
      this.year = d.year;
   }

    /**
     * Checks if the year is a leap year.
     * @param year of the date
     * @return true if the year is a leap year
     * @author Shashwat Singh
     */
   private boolean isLeap(int year){
      boolean leapYear = false;
      if((year % Month.QUADRENNIAL)== 0){//check if year is evenly divisible by 4
               if((year % Month.CENTENNIAL) == 0){//check if year is evenly divisible by 100
                  if((year % Month.QUATERCENTENNIAL) == 0){//check if year is evenly divisible by 400
                     leapYear = true;
                  }
               }
               else{
                  leapYear = true;
               }
         }
      return leapYear;
   }//isLeap()

    /**
     * Checks if the date is valid
     * @return true if the date is valid
     * @author Shashwat Singh
     */
   public boolean isValid()
   {
       boolean correct_format = false;
       int DAYBIGZERRO = 0;
       if(day  >  DAYBIGZERRO){
			if(month == Month.JAN ||month == Month.MAR || month == Month.JUL || month == Month.AUG || month == Month.OCT || month == Month.DEC || month == Month.MAY){
				if(day <= Month.DAYS_ODD){
					correct_format = true;
				}
			}
			if(month == Month.APR || month == Month.JUN || month == Month.SEP || month == Month.NOV){
				if(day <= Month.DAYS_EVEN){
					correct_format = true;
				}
			}
			if(month == Month.FEB){
				if(day <= Month.DAYS_FEB && isLeap(year) == false){
					correct_format = true;
				}
            if(day <= Month.DAYS_FEB_LEAP && isLeap(year) == true){
                    correct_format = true;
                }
			}
       }
	   return correct_format;
   }//isValid()

    /**
     * Puts month, day, and year into a String format
     * @return String value of the date
     * @author Shashwat Singh
     */
   @Override
   public String toString()
   {
       //use the format "month/day/year"
      return ""+ month + "/" + day + "/" + year;
   }//toString()

    /**
     * Checks to see if two dates are equal.
     * @param obj of some date
     * @return true if the two dates are the same
     * @author Shashwat Singh
     */
   @Override
   public boolean equals(Object obj)
   {
      if(obj instanceof Date){ // checking if the object is an instance of the Date class
         Date date = (Date)obj;
         if(date.day == day && date.month == month && date.year == year){
            return true;
         }
      }
       return false;
   }//equals()

   //This is the test bed main
   public static void main(String args[]){
      //Testing public Date(String d)
      Date date1 = new Date("2/2/2020");
      //Testing public Date(Date d)
      Date date2 = new Date(date1);
      Date date4 = new Date("1/2/2020");
      //Test Case 1
      System.out.println(date1.toString());
       //Test Case 2
      System.out.println(date2.toString());
      //Test Case 3
       if(date2.equals(date1)== true){
           System.out.println("equal");
       }
      else{
          System.out.println("not equal");
       }
      //Test Case 4
       if(date2.equals(date4)== true){
           System.out.println("equal");
       }
       else{
           System.out.println("not equal");
       }
       //Test Case 5
       if(date1.equals("Random")== true){
           System.out.println("equal");
       }
       else{
           System.out.println("not equal");
       }
       Date date5 = new Date("0/2/2020");
       Date date7 = new Date("2/29/2019");
       Date date8 = new Date("2/0/2020");
       Date date9 = new Date("1/31/1995");
       Date date10 = new Date("9/31/2018");
       Date date11 = new Date("2/29/2020");
       Date date12 = new Date("2/30/2020");
       //Test Case 6
       if(date5.isValid()== true){
           System.out.println("valid");
       }
       else{
           System.out.println("not valid");
       }
       //Test Case 7
       if(date7.isValid()== true){
           System.out.println("valid");
       }
       else{
           System.out.println("not valid");
       }
       //Test Case 8
       if(date8.isValid()== true){
           System.out.println("valid");
       }
       else{
           System.out.println("not valid");
       }
       //Test Case 9
       if(date9.isValid()== true){
           System.out.println("valid");
       }
       else{
           System.out.println("not valid");
       }
       //Test Case 10
       if(date10.isValid()== true){
           System.out.println("valid");
       }
       else{
           System.out.println("not valid");
       }
       //Test Case 11
       if(date11.isValid()== true){
           System.out.println("valid");
       }
       else{
           System.out.println("not valid");
       }
       //Test Case 12
       if(date12.isValid()== true){
           System.out.println("valid");
       }
       else{
           System.out.println("not valid");
       }

   }
}//Date