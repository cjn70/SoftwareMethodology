/**
 * This class is the first controller class that handles the adding of toppings to a pizza, and adding
 * pizzas to the order.
 * @author Craig Natoli Shashwat Singh
 */
package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;


import java.net.URL;
import java.util.Collections;
import java.util.ResourceBundle;
import java.util.ArrayList;

public class ViewController1 implements Initializable {

    @FXML
    private ComboBox<String> style;

    @FXML
    private ComboBox<String> size;

    @FXML
    private ImageView imageView;

    @FXML
    private ListView<String> selectToppings;

    @FXML
    private ListView<String> selectedToppings;

    @FXML
    private Button toppingAdd;

    @FXML
    private Button removeTopping;

    @FXML
    private Button add;

    @FXML
    private Button clearSelection;

    @FXML
    private TextArea textArea;

    @FXML
    private Button showorder;

    ArrayList<String> toppingsOnPizza = new ArrayList<String>();
    ArrayList<Pizza> pizzas = new ArrayList<Pizza>();

    /**
     * Initializes the two combo boxes to Build Your Own and the size medium also this method initializes the toppings
     * in the listview.
     * @param url The url used to resolve relative paths for the root object, or null if the location is not known.
     * @param resourceBundle The resources used to localize the root object, or null if the root object was not localized.
     * @author Craig Natoli
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        style.setValue("Build Your Own");
        size.setValue("medium");
        ObservableList<String> toppings = FXCollections.observableArrayList("Beef","Cheese","Chicken","Green Pepper","Ham","Mushroom","Onion","Pepperoni","Pineapple","Sausage");
        selectToppings.setItems(toppings);
        removeTopping.setDisable(true);
    }

    /**
     * Sets what toppings are available to be seen when a particular type of pizza is selected in the combo box.
     * @author Craig Natoli
     */
    private void setAvailableToppings(){
        if(style.getValue().equals("Deluxe") == true){//checks if deluxe pizza is selected
            selectToppings.getItems().clear();
            ObservableList<String> toppings1 = FXCollections.observableArrayList("Sausage","Pepperoni","Green Pepper","Onion","Mushroom");
            selectedToppings.setItems(toppings1);
            toppingsOnPizza.clear();
            toppingsOnPizza.addAll(Collections.singleton("Sausage"));
        }
        if(style.getValue().equals("Hawaiian") == true){//checks if Hawaiian pizza is selected
            selectToppings.getItems().clear();
            ObservableList<String> toppings1 = FXCollections.observableArrayList("Ham","Pineapple");
            selectedToppings.setItems(toppings1);
            toppingsOnPizza.clear();
            toppingsOnPizza.addAll(Collections.singleton("Ham"));
        }
        if(style.getValue().equals("Build Your Own") == true){//checks if build your own pizza is selected
            toppingsOnPizza.clear();
            selectedToppings.getItems().clear();
            ObservableList<String> toppings1 = FXCollections.observableArrayList("Beef","Cheese","Chicken","Green Pepper","Ham","Mushroom","Onion","Pepperoni","Pineapple","Sausage");
            selectToppings.setItems(toppings1);
        }
    }

    /**
     * Displays the correct image for the combo box selected and displays the correct toppings available.
     * @param event is an "event" that your listener catches, as sent by a dispatcher
     * @author Craig Natoli
     */
    @FXML
    public void pizzaSelected(ActionEvent event){
            Image image = new Image("Deluxe.jpg");
            Image image2 = new Image("Hawaiian.jpg");
            Image image3 = new Image("buildOwn.jpg");
            if (style.getValue().equals("Deluxe") == true) {//checks if deluxe pizza is selected
                imageView.setImage(image);
                toppingAdd.setDisable(true);
                setAvailableToppings();
            }
            if (style.getValue().equals("Hawaiian") == true) {//checks if hawaiian pizza is selected
                imageView.setImage(image2);
                toppingAdd.setDisable(true);
                setAvailableToppings();
            }
            if (style.getValue().equals("Build Your Own") == true) {//checks if build your own pizza is selected
                imageView.setImage(image3);
                toppingAdd.setDisable(false);
                clearSelection.setDisable(false);
                setAvailableToppings();
            }
    }

    /**
     * Adds topping to the when you build your own pizza.
     * @param event is an "event" that your listener catches, as sent by a dispatcher
     * @author Craig Natoli
     */
    @FXML
    public void addTopping(ActionEvent event) {
        try {
            int myItems = selectToppings.getSelectionModel().getSelectedIndex();
            ObservableList<String> myItems1 = selectToppings.getSelectionModel().getSelectedItems();
            String temp = myItems1.get(0);
            selectToppings.getItems().remove(myItems);
            selectedToppings.getItems().add(temp);
            toppingsOnPizza.add(temp);
            removeTopping.setDisable(false);
            if (toppingsOnPizza.size() == 6) {//checking if 6 toppings have been selected
                toppingAdd.setDisable(true);
                textArea.appendText("6 toppings is the max amount of toppings aloud to be added to the pizza!!!!\n");
            }
        }
        catch(Exception e){
           textArea.appendText("Must choose a topping to add a topping !!!!\n");
        }

    }

    /**
     * Removes toppings when you build your pizza.
     * @param event is an "event" that your listener catches, as sent by a dispatcher
     * @author Craig Natoli
     */
    @FXML
    public void removePizzaTopping(ActionEvent event) {
        try {
            int myItems = selectedToppings.getSelectionModel().getSelectedIndex();
            ObservableList<String> myItems1 = selectedToppings.getSelectionModel().getSelectedItems();
            String temp = " ";
            temp = myItems1.get(0);
            selectedToppings.getItems().remove(myItems);
            selectToppings.getItems().add(temp);
            toppingsOnPizza.remove(temp);
            toppingAdd.setDisable(false);
            if (toppingsOnPizza.isEmpty()) {//checking if the list of toppings added is empty
                removeTopping.setDisable(true);
            } else {
                removeTopping.setDisable(false);
            }
        }
        catch(Exception e){
            textArea.appendText("Must choose a topping to remove topping !!!!\n");
        }
    }

    /**
     * Helper method that clears and resets the ordering interface after an order has been processed, sets everything to
     * the default.
     * @author Craig Natoli
     */
    private void clearReset(){
        selectedToppings.getItems().clear();
        selectToppings.getItems().clear();
        ObservableList<String> toppings2 = FXCollections.observableArrayList("Beef", "Cheese", "Chicken", "Green Pepper", "Ham", "Mushroom", "Onion", "Pepperoni", "Pineapple", "Sausage");
        selectToppings.setItems(toppings2);
        toppingsOnPizza.clear();
        removeTopping.setDisable(true);
        toppingAdd.setDisable(false);
        style.setValue("Build Your Own");
        size.setValue("medium");
    }

    /**
     * Adds the pizza selected to the order.
     * @param event is an "event" that your listener catches, as sent by a dispatcher
     * @author Craig Natoli
     */
    @FXML
    public void addToOrder(ActionEvent event) {
        if(style.getValue().equals("Deluxe") == true){//checking if the deluxe pizza has been selected
            Deluxe deluxe = new Deluxe(style.getValue(),size.getValue());
            pizzas.add(deluxe);
            textArea.appendText("Your Deluxe pizza has been added to the order.\n");
        }
        if(style.getValue().equals("Hawaiian") == true){//checking if the hawaiian pizza has been selected
            Hawaiian hawaiian = new Hawaiian(style.getValue(),size.getValue());
            pizzas.add(hawaiian);
            textArea.appendText("Your Hawaiian pizza has been added to the order.\n");
        }
        if(style.getValue().equals("Build Your Own") == true){//checking if the build your own pizza has been selected
            if(toppingsOnPizza.size() >= 1){// making sure at least one topping has been added to the pizza
                ArrayList<String> newTopping = new ArrayList<String>();
                newTopping.addAll(toppingsOnPizza);
                BuildYourOwn buildyouown = new BuildYourOwn(style.getValue(), size.getValue(), newTopping);
                pizzas.add(buildyouown);
                textArea.appendText("Your Build Your Own pizza has been added to the order.\n");
            }
            else{
                textArea.appendText("Must choose at least 1 topping\n");
            }
        }
        clearReset();
        style.setValue("Build Your Own");
        size.setValue("medium");
    }

    /**
     * Removes toppings from the selectedtoppings listview.
     * @param event is an "event" that your listener catches, as sent by a dispatcher
     * @author Craig Natoli
     */
    @FXML
    public void emptySelection(ActionEvent event) {
        if(toppingsOnPizza.size() >=1 ){//checking that at least one topping has been added to the pizza to clear toppings
            clearReset();
        }
        else {
            textArea.appendText("Must Choose at least 1 topping to clear the selected toppings when building your own pizza\n");
        }
    }

    /**
     * displays another scene to show the users list of pizzas in the order by loading View2.fxml.
     * @param event is an "event" that your listener catches, as sent by a dispatcher
     * @author Craig Natoli
     */
    @FXML
    public void displayOrder(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("View2.fxml"));
            Parent root = loader.load();
            ViewController2 viewController2 = loader.getController();
            viewController2.displayOrder(pizzas);
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setTitle("Total Of Your Order");
            stage.show();

        }
        catch (Exception e) {
            textArea.appendText(e + "\n");
        }
    }

}
