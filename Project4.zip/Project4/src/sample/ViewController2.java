/**
 * This controller class is used for displaying the order and clearing the order.
 * @author Craig Natoli Shashwat Singh
 */
package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

import java.util.ArrayList;

public class ViewController2 {
    @FXML
    private TextArea textArea2;
    @FXML
    private Button clear;
    @FXML
    private Button back;

    private ArrayList<Pizza> totalPizzas = new ArrayList<Pizza>();

    /**
     * displays the order of all the pizzas the user selected.
     * @param pizzas arraylist of pizzas
     * @author Craig Natoli
     */
    public void displayOrder(ArrayList<Pizza> pizzas) {
        if(pizzas.size() > 0){
            int total = 0;
            totalPizzas = pizzas;
            String totalDescription = " ";
            for (int i = 0; i < pizzas.size(); i++) {
                totalDescription += pizzas.get(i) + "Price: $" + pizzas.get(i).pizzaPrice() + "\n \n";
                total += pizzas.get(i).pizzaPrice();
            }
            textArea2.appendText(totalDescription + "\nTotal: $" + total);
        }
        else{
            textArea2.appendText("0 Pizzas are in the order");
        }
    }

    /**
     * deletes the order
     * @param event is an "event" that your listener catches, as sent by a dispatcher
     * @author Craig Natoli
     */
    @FXML
    public void deleteOrder(ActionEvent event) {
        totalPizzas.clear();
        textArea2.clear();
    }

    /**
     * closes the window.
     * @param event is an "event" that your listener catches, as sent by a dispatcher
     * @author Craig Natoli
     */
    @FXML
    public void closeWindow(ActionEvent event) {
        Stage stage = (Stage) back.getScene().getWindow();
        stage.close();
    }

}
