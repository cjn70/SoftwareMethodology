/**
 * This class handles creating a Hawaiian pizza and calculating the price of a Hawaiian pizza.
 * @author Craig Natoli Shashwat Singh
 */
package sample;

public class Hawaiian extends Pizza {
    private static final String SMALL = "small";
    private static final String MEDIUM = "medium";
    private static final String LARGE = "large";
    private static final int SMALLPRICE = 8;
    private static final int MEDIUMPRICE = 10;
    private static final int LARGEPRICE = 12;

    /**
     * Parametrize constructor that initializes the style and size of the pizza.
     * @param style of the pizza
     * @param size of the pizza
     * @author Shashwat Singh
     */
    public Hawaiian (String style, String size){
        super(style,size);
    }

    /**
     * Calculates the price of the pizza
     * @return the price of the pizza
     * @authror Shashwat Singh
     */
    @Override
    public int pizzaPrice() {
        if(super.size.equals(SMALL)){
            return SMALLPRICE;
        }
        if(super.size.equals(MEDIUM)){
            return MEDIUMPRICE;
        }
        if(super.size.equals(LARGE)){
            return LARGEPRICE;
        }
        return 0;
    }

    /**
     * Displays the correct information for a Hawaiian pizza.
     * @return a string for the description of a pizza.
     * @author Shashwat Singh
     */
    @Override
    public String toString(){
        return super.toString() + "TOPPINGS:\nHam\nPineapple\n";
    }
}
