/**
 * This class is the parent abstract class where first name, last name,
 * and number of credits of each student are declared.
 * @author Craig Natoli Shashwat Singh
 */
package sample;
public abstract class Student implements Comparable{
    private String fname;
    private String lname;
    protected int  credit;

    /**
     * This is the Student parameterized constructor
     * @param fname first name of the student
     * @param lname last name of the student
     * @param credit number of credits the student is taking
     * @author Craig Natoli
     */
    public Student(String fname, String lname, int credit){
        this.fname = fname;
        this.lname = lname;
        this.credit = credit;
    }

    /**
     * Checks to see if both fname and lname are the same
     * @param obj the first and last name of the student.
     * @return 0 if both fname and lname are lexicographically the same or equal, -1 if fname are the same and lname
     * is lexicographically less than obj.lname or 1 if fname are the same and lname is lexicographically greater
     * than obj.lname, or if both fnames are not similar -1 if fname is lexicographically less than obj.fname,
     * or 1 if fname is lexicographically greater than obj.fname
     * @author Craig Natoli
     */
    public int compareTo(Object obj)
    {
        int compare = 0;
        if (obj instanceof Student)
        {
            Student student = (Student) obj;
            //return 0 if fname and lname of two students are equal
            if (this.fname.equalsIgnoreCase(student.fname) == true && this.lname.equalsIgnoreCase(student.lname) == true){
                return 0;
            }
            compare = this.fname.compareToIgnoreCase(student.fname);

            if(compare == 0){
                compare = this.lname.compareToIgnoreCase(student.lname);
                //return -1 if fname are equal but lname is lexicographically less than obj.lname
                if (compare <= -1)
                    return -1;
                //return 1 if fname are equal but lname is lexicographically greater than obj.lname
                else
                    return 1;
            }
            else{
                //return -1 if fname is lexicographically less than obj.fname
                if (compare <= -1)
                    return -1;
                //return 1 if fname is lexicographically greater than obj.fname
                else
                    return 1;
            }
        }
        return 1;
    }
    @Override
    /**
     * Establishes the students information into a String.
     * @return String of the Students information
     * @author Craig Natoli
     */
    public String toString(){
        return "Name: "+ fname + " " + lname + ", Number of Credits: " + credit;
    }

    /**
     * This is meant to be overrided by subclasses to have a concrete implementation
     * of this method.
     * @return tuition due
     * @author Craig Natoli
     */
    public abstract int tuitionDue();

}
