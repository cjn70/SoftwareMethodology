/**
 * This class is a subclass of Student that calculates, and implements
 * the correct tuition due for instate students.
 * @author Craig Natoli Shashwat Singh
 */
package sample;
public class Instate extends Student {
    private int funds;
    //constants required for this class
    private static final int CREDIT = 433;
    private static final int PART_TIME = 846;
    private static final int FULL_TIME = 1441;
    private static final int CREDIT_NUM = 12;
    private static final int CREDIT_MAX = 15;
    /**
     * Parameterized constructor that fills parameters of the superclass
     * and sets the funds amount.
     * @param fname first name of the student
     * @param lname last name of the student
     * @param credit number of credits student will take
     * @param funds amount of funding the student will receive
     * @author Craig Natoli
     */
    public Instate(String fname, String lname, int credit, int funds){
        super(fname,lname,credit);
        this.funds = funds;
    }

    /**
     * Establishes the students information into a String
     * @return String of the students information along with the amount of funds for
     * full-time student, or a String of the students information along with 0 funds
     * for part-time students.
     * @author Craig Natoli
     */
    @Override
    public String toString(){
        if(super.credit >= 12){
            return super.toString() + ", Status: Instate" + ", funds: "+ funds;
        }
        else{ //setting the student fund amount to 0 becuase they are part-time
            funds = 0;
            return super.toString() + ", Status: Instate" + ", funds: "+ funds;
        }
    }

    /**
     * Calculates the correct tuition an instate student will pay based off of
     * if the student is part-time or full-time, and the amount of funding and
     * credits they have.
     * @return amount of tuition the student will pay
     * @author Craig Natoli
     */
    @Override
    public int tuitionDue(){
        int total_due = 0;
        if(super.credit >= CREDIT_NUM && super.credit < CREDIT_MAX){
          total_due = super.credit * CREDIT + FULL_TIME - funds;
        }
        else if(super.credit >= CREDIT_MAX){
            total_due = CREDIT_MAX * CREDIT + FULL_TIME - funds;
        }
        else if (super.credit < CREDIT_NUM){
            total_due = super.credit * CREDIT + PART_TIME;
        }
        return total_due;
    }
    //Test bed main
    public static void main(String args[]){
        Instate in = new Instate("craig","natoli",8,0);
        Instate in5 = new Instate("craig","natoli",12,500);
        Instate in2 = new Instate("craig1","natoli",14,1000);
        Instate in3 = new Instate("craig2","natoli",15,2000);
        Instate in4 = new Instate("craig3","natoli",17,0);
        //Test Case 0
        System.out.println(in);
        //Test case 1
        System.out.println(in5);
        //Test Case 2
        System.out.println(in.tuitionDue());
        //Test case 3
        System.out.println(in2.tuitionDue());
        //Test Case 4
        System.out.println(in3.tuitionDue());
        //Test Case 5
        System.out.println(in4.tuitionDue());
    }
}
