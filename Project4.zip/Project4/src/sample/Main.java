/**
 * This class displays the user interface to select and order pizzas.
 * @author Craig Natoli Shashwat Singh
 */
package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {
    /**
     * loads View1.fxml file, sets the primary stages title and scene
     * @param primaryStage instance of a Stage
     */
    @Override
    public void start(Stage primaryStage){
        try {
            Parent root = FXMLLoader.load(getClass().getResource("View1.fxml"));
            primaryStage.setTitle("My Pizza Store");
            primaryStage.setScene(new Scene(root, 800, 850));
            primaryStage.show();
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

    /**
     * launches the program
     * @param args arguments from the command line
     */
    public static void main(String[] args) {
        launch(args);
    }
}
