/**
 * The parent class that initializes style, size and toppings and will also be inherited by the subclasses.
 * @author Craig Natoli Shashwat Singh
 */
package sample;

import java.util.ArrayList;
public abstract class Pizza {
    protected String style;
    protected String size;
    protected ArrayList<String> toppings;

    /**
     * Parameterize constructor that initializes the style, size, and toppings of a pizza.
     * @param style of the pizza
     * @param size of the pizza
     * @param toppings added to the pizza
     * @author Shashwat Singh
     */
    public Pizza(String style, String size, ArrayList<String> toppings) {
        this.style = style;
        this.size = size;
        this.toppings = toppings;
    }

    /**
     * Parametrize constructor that initializes the style and size of the pizza.
     * @param style of pizza
     * @param size of pizza
     * @author Shashwat Singh
     */
    public Pizza(String style, String size) {
        this.style = style;
        this.size = size;
    }

    /**
     * Will be overridden in the subclasses to calculate the correct price of pizza.
     * @return the price of the pizza.
     * @author Shashwat Singh
     */
    public abstract int pizzaPrice();

    /**
     * Gets the style and size information of a pizza.
     * @return string of the style and size of pizza.
     * @author Shashwat Singh
     */
    public String toString(){
        return "STYLE: " + style + "\nSIZE: " + size + "\n";
    }
}
