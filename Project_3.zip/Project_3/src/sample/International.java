/**
 * This class is a subclass of Student that calculates, and implements
 * the correct tuition due for international students.
 * @author Craig Natoli Shashwat Singh
 */
package sample;
public class International extends Student{
    private boolean exchange;
    //constants required for this class
    private static final int CREDIT = 945;
    private static final int PART_TIME = 846;
    private static final int FULL_TIME = 1441;
    private static final int CREDIT_NUM = 12;
    private static final int INTERNATIONAL_FEE = 350;
    private static final int CREDIT_MAX = 15;

    /**
     * Parameterized constructor that fills parameters of the superclass
     * and sets the boolean value of exchange
     * @param fname first name of the student
     * @param lname last name of student
     * @param credit number of credits
     * @param exchange is exchange student or not
     * @author Craig Natoli
     */
    public International (String fname, String lname, int credit, boolean exchange){
        super(fname,lname,credit);
        this.exchange = exchange;
    }
    /**
     * Establishes the international students information
     * @return String of international student information
     * @author Craig Natoli
     */
    @Override
    public String toString(){
        if(exchange == true) {
            return super.toString() + ", Status: International" + ", Exchange Student: True ";
        }
        else{
            return super.toString() + ", Status: International"+" , Exchange Student: False ";
        }

    }

    /**
     * Calculates the correct tuition due for an international student based off if the
     * student is part-time, full-time, or an exchange student.
     * @return amount of tuition the student will pay
     * @author Craig Natoli
     */
    @Override
    public int tuitionDue() {
        int total_due = 0;
        if(exchange == true) {
                total_due = FULL_TIME + INTERNATIONAL_FEE;
        }
        else{
            if(super.credit >= CREDIT_MAX){
                total_due = CREDIT_MAX * CREDIT + FULL_TIME + INTERNATIONAL_FEE;
            }
            else if(super.credit >= CREDIT_NUM && super.credit < CREDIT_MAX){
                total_due = super.credit * CREDIT + FULL_TIME + INTERNATIONAL_FEE;
            }
            else if(super.credit < CREDIT_NUM){
                total_due = super.credit * CREDIT + PART_TIME + INTERNATIONAL_FEE;
            }
        }
        return total_due;

    }
    //Test bed main
    public static void main(String args[]){
        International out = new International("craig","natoli",11,true);
        International out6 = new International("craig","natoli",11,false);
        International out2 = new International("craig2","natoli",14,false);
        International out3 = new International("craig3","natoli",15,false);
        International out4 = new International("craig4","natoli",17,true);
        International out5 = new International("craig5","natoli",9,false);
        //Test Case 0
        System.out.println(out);
        //Test Case 1
        System.out.println(out6);
        //Test Case 2
        System.out.println(out.tuitionDue());
        //Test Case 3
        System.out.println(out2.tuitionDue());
        //Test Case 4
        System.out.println(out3.tuitionDue());
        //Test Case 5
        System.out.println(out4.tuitionDue());
        //Test Case 6
        System.out.println(out5.tuitionDue());
    }
}
