import java.io.*;
/**
   This is the driver class that creates an instance of ProjectManager.
   @author Craig Natoli Shashwat Singh
 */
public class Prog1
{
   public static void main(String [] args)throws IOException
   {
      new ProjectManager().run();
   } 
}
