/**
 This class constructs a TeamMember,checks if the team member already exists,
 checks if two TeamMembers are the same, and prints out the TeamMember.
 @author Craig Natoli Shashwat Singh
 */
public class TeamMember
{
   private String name;
   private Date startDate;

   /**
    * constructs a TeamMember.
    * @param nm String is assgined to name attribute
    * @param date instance of Date is assigned to the startDate attribute
    * @author Shashwat Singh
    */
   public TeamMember(String nm, Date date)
   {
      startDate = date;
      name = nm;
   }

   /**
    * Gets the private startDate attribute from this class.
    * @return startDate of the Date in this class
    * @author Shashwat Singh
    */
   public Date getStartDate()
   {
      return startDate;
   }

   /**
    * Checks to see if two TeamMembers are the same and checks
    * if the object is an instance of TeamMember.
    * @param obj instance of Object to compare TeamMember to
    * @return true if two TeamMembers are the same
    * @author Shashwat Singh
    */
   @Override
   public boolean equals(Object obj)
   {
      if(obj instanceof TeamMember){ // checking if the object is an instance of the TeamMember
         TeamMember member = (TeamMember)obj;
         if(member.name.equals(name) && member.startDate.equals(startDate)){
            return true;
         }         
      }
      return false;
   }

   /**
    * Puts name and StartDate into a String format.
    * @return String value of the date
    * @author Shashwat Singh
    */
   @Override
   public String toString()
   {
       //name + " " + startDate;
      return name + " " + startDate;
   }
   //This test bed main for this class
   public static void main(String [] args)
   {
      Date date1 = new Date("1/4/2020");
      TeamMember team1 = new TeamMember ("Craig",date1);
      Date date2 = new Date("1/4/2020"); 
      TeamMember team2 = new TeamMember ("Craig",date2);
      Date date3 = new Date("1/4/2020");
      TeamMember team3 = new TeamMember ("Craig",date3);
      Date date4 = new Date("1/4/2020");
      TeamMember team4 = new TeamMember ("Craig1",date4);
      Date date5 = new Date("1/5/2020");
      TeamMember team5 = new TeamMember ("Craig",date5);
      Date date6 = new Date("1/4/2020");
      TeamMember team6 = new TeamMember ("Craig",date6);
      //Test Case 1
      System.out.println(team1.toString());
      //Test Case 2
      if(team1.equals(team2) == true ){
         System.out.println("equal");
      }
      else{
         System.out.println("not equal");
      }
      //Test Case 3
      if(team3.equals(team4) == true ){
         System.out.println("equal");
      }
      else{
         System.out.println("not equal");
      }
      //Test Case 4
      if(team5.equals(team6) == true ){
         System.out.println("equal");
      }
      else{
         System.out.println("not equal");
      }
      //Test Case 5
      if(team5.equals("Random") == true ){
         System.out.println("equal");
      }
      else{
         System.out.println("not equal");
      }
      //Test Case 6
      System.out.println(team1.startDate);
   }
}
