/**
 * Container class that is responsible for growing, removing, and printing
 * the contents of the students array.
 * @author Craig Natoli Shashwat Singh
 */
public class StudentList {
    private int numStudent;
    private Student [] students;
    //constants required for this class
    private static final int NOT_FOUND = -1;
    private static final int GROW_SIZE = 4;
    private static final int STARTARRAY = 0;
    private static final int ZEROSTUDENTS = 0;
    private static final int EQUAL = 0;
    private static final int ZEROMEMBERS = 0;

    /**
     * Default constructor that initializes the classes data members.
     * @author Shashwat Singh
     */
    public StudentList(){
        numStudent = 0;
        students = new Student[GROW_SIZE];
    }

    /**
     * This will grow the array if he array is full by 4 indexes if the
     * array is full.
     * @author Shashwat Singh
     */
    private void grow(){
            int i = 0;
            Student temp[] = null;
            if((numStudent+1) > students.length) {
                temp = new Student[students.length + GROW_SIZE];
                for (i = 0; i < students.length; i++) {
                    temp[i] = students[i];
                }
                students = temp;
            }
    }

    /**
     * Adds students to the students list.
     * @param student the student to be added
     * @author Shashwat Singh
     */
    public void add(Student student){
        numStudent ++;
        if(numStudent == students.length){// only grow the array when the end of the array has been reached
            grow();
        }
        if((numStudent -1) == STARTARRAY) {
            students[0] = student;
        }
        else{
            students[numStudent - 1] = student;
        }
    }

    /**
     * Finds the index number of the student.
     * @param student the student to be searched for
     * @return the index of the student or -1 if not found
     * @author Shashwat Singh
     */
    private int find(Student student){
        int i = 0;
        int found_Location = 0;
        if(numStudent > ZEROSTUDENTS) {
            for (i = 0; i < numStudent; i++) {
                if (students[i].compareTo(student) == EQUAL) {//Used compareTo method
                    found_Location = i;
                    break;
                } else {
                    found_Location = NOT_FOUND;
                }
            }
        }
        return found_Location;
    }

    /**
     * removes student from the list, sets last index to null and puts last student
     * in the array in the removed student index position.
     * @param student the student to be removed
     * @return true if the student was removed else false
     * @author Shashwat Singh
     */
    public boolean remove(Student student){
        boolean removed = false;
        Student temp[] = null;
        temp = new Student[1];
        int location = find(student);
        if(location != NOT_FOUND){
            if(numStudent > ZEROMEMBERS){
                temp[0] = students[numStudent-1];
                students[location] = temp[0];
                students[numStudent-1] = null;
                numStudent -- ;
                removed = true;
            }
            else{
                students[0] = null;
                numStudent -- ;
                removed = true;
            }
        }
        return removed;
    }

    /**
     * Checks if the first element in the list is null
     * @return true if element 0 is null else false
     * @author Shashwat Singh
     */
    public boolean isEmpty(){
        boolean EMPTY = false;
        if(students[0] == null){
            return true;
        }
        return EMPTY;
    }

    /**
     * checks if the student is in the students array
     * @param newStudent student to be found
     * @return true if student found, else false.
     * @author Shashwat Singh
     */
    public boolean contains(Student newStudent){
        boolean doesContain = false;
        int i = 0;
        for(i = 0; i < numStudent; i ++){
            if(students[i].compareTo(newStudent) == 0){//Using compareTo() from Student
                return true;
            }
        }
        return doesContain;
    }

    /**
     * prints the contents of the students array
     * @author Shashwat Singh
     */
    public void print() {
        int i = 0;
        for(i = 0; i < numStudent; i++){
            System.out.println(students[i] + ", Tuition Due: $" +students[i].tuitionDue());
        }
    }

}
