/**
 * This class creates a build your own pizza and also calculates the correct price of a pizza with its size
 * and number of toppings.
 * @author Criag Natoli Shashwat Singh
 */
package sample;

import java.util.ArrayList;
import java.util.Iterator;

public class BuildYourOwn extends Pizza{
    private static final String SMALL = "small";
    private static final String MEDIUM = "medium";
    private static final String LARGE = "large";
    private static final int SMALLPRICE = 5;
    private static final int MEDIUMPRICE = 7;
    private static final int LARGEPRICE = 9;
    private static final int TOPPINGS = 2;

    /**
     * Parametrize constructor that initializes the style , size and toppings of the pizza.
     * @param style of the pizza
     * @param size of the pizza
     * @param toppings on the pizza
     * @author Shashwat Singh
     */
    public BuildYourOwn(String style, String size, ArrayList<String> toppings){
        super(style,size,toppings);
    }

    /**
     * Calculates the price of the pizza.
     * @return the price of the pizza.
     * @author Shashwat Singh
     */
    @Override
    public int pizzaPrice() {
        if(super.size.equals(SMALL) == true){
            return SMALLPRICE + (TOPPINGS * toppings.size());
        }
        if(super.size.equals(MEDIUM) == true){
            return MEDIUMPRICE + (TOPPINGS * toppings.size());
        }
        if(super.size.equals(LARGE) == true){
            return LARGEPRICE + (TOPPINGS * toppings.size());
        }
        return 0;
    }

    /**
     * Displays the correct information for build you own pizza.
     * @return string of the build your own pizza information
     * @author Shashwat Singh
     */
    @Override
    public String toString(){
        String temp = " ";
        String toppingList = " ";
        Iterator<String> i = super.toppings.iterator();
        while(i.hasNext()){
            temp  = i.next();
            toppingList +=  temp + "\n";
        }
        return super.toString() + "TOPPINGS SELECTED:\n" + toppingList;
    }
}
