/**
 * This class allows the program to have a interactive user interface to add, remove, and print information
 * about a student.
 * @author Craig Natoli Shashwat Singh
 */
package sample;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.event.ActionEvent;

public class Controller {
    StudentList cs213 = new StudentList();
    private static final int onlyFund = 0;
    private static final int fundAndCredit = 1;
    @FXML
    private RadioButton inState;
    @FXML
    private RadioButton outState;
    @FXML
    private RadioButton international;
    @FXML
    private CheckBox box1;
    @FXML
    private CheckBox box2;
    @FXML
    private CheckBox box3;
    @FXML
    private Button add;
    @FXML
    private Button remove;
    @FXML
    private Button print;
    @FXML
    private TextField fname;
    @FXML
    private TextField lname;
    @FXML
    private TextField credit;
    @FXML
    private TextField fund;
    @FXML
    private TextArea textArea;

    /**
     * This method displays specific errors to the user about incomplete text fields when adding.
     * @author Shashwat Singh
     */
    private void emptyFieldAdd(){
        if(fname.getText().trim().equals("") && lname.getText().trim().equals("") == false && credit.getText().trim().equals("") == false){
            textArea.appendText("Must enter in first name when you ADD a student\n");
        }
        if(lname.getText().trim().equals("") && credit.getText().trim().equals("") == false && fname.getText().trim().equals("") == false){
            textArea.appendText("Must enter in last name when you ADD a student\n");
        }
        if(credit.getText().trim().equals("") && lname.getText().trim().equals("") == false && fname.getText().trim().equals("") == false){
            textArea.appendText("Must enter in a credit amount when you ADD a student\n");
        }
        if(fname.getText().trim().equals("") && lname.getText().trim().equals("") && credit.getText().trim().equals("") == false){
            textArea.appendText("Must enter in first and last name when you ADD a student\n");
        }
        if(fname.getText().trim().equals("") && lname.getText().trim().equals("") == false && credit.getText().trim().equals("")){
            textArea.appendText("Must enter in first name and credit amount when you ADD a student\n");
        }
        if(lname.getText().trim().equals("") && credit.getText().trim().equals("")  && fname.getText().trim().equals("") == false){
            textArea.appendText("Must enter in last name and credit amount when you ADD a student\n");
        }
        if(credit.getText().trim().equals("") && lname.getText().trim().equals("") && fname.getText().trim().equals("")){
            textArea.appendText("Must enter in a first name, last name, and credit amount when you ADD a student\n");
        }
    }

    /**
     * This method displays specific errors to the user about incomplete text fields when removing.
     * @author Shashwat Singh
     */
    private void emptyFieldRemove(){
        if(fname.getText().trim().equals("") && lname.getText().trim().equals("") == false )// if fname  is empty
        {
            textArea.appendText("Must enter in a first name when you REMOVE\n");
        }
        else if(lname.getText().trim().equals("") && fname.getText().trim().equals("") == false )// if lname is empty
        {
            textArea.appendText("Must enter in a last name when you REMOVE\n");
        }
        else if(lname.getText().trim().equals("") && fname.getText().trim().equals(""))// if credit is empty
        {
            textArea.appendText("Must enter in a first and last name when you REMOVE\n");
        }
    }

    /**
     * Checks what radio button has been selected and places the correct student information based off of the corresponding radio
     * button that is selected.
     * @param credit1 number of credit entered
     * @author Shashwat Singh
     */
    private void addType(int credit1){
        if (inState.isSelected() == true) {
            addInstate(fname.getText(),lname.getText(),credit1);
        }
        if (outState.isSelected() == true) {
            addOutState(fname.getText(),lname.getText(),credit1);
        }
        if (international.isSelected() == true) {
            addInternational(fname.getText(),lname.getText(),credit1);
        }
        if(inState.isSelected() == false && outState.isSelected() == false && international.isSelected() == false){
            textArea.appendText("Must choose in-state, out-of-state, or international student\n");
        }
    }

    /**
     * Clears the text fields and resets all radio buttons.
     * @author Shashwat Singh
     */
    private void clear(){
        fname.clear();
        lname.clear();
        credit.clear();
        fund.clear();
        inState.setSelected(false);
        outState.setSelected(false);
        international.setSelected(false);
        box1.setSelected(false);
        box2.setSelected(false);
        box3.setSelected(false);
        box1.setDisable(true);
        box2.setDisable(true);
        box3.setDisable(true);
        fund.setDisable(true);
    }

    /**
     * checks if only a non-numeric is entered into the funding text field or both funding and credit
     * @param both indicates to the user that both fund and credits have a non-numeric value or only fund
     * has a non-numeric value
     * @return true if non-numeric has been entered for fund
     * @author Craig Natoli
     */
    private boolean nonNumeric(int both){
        boolean except = false;
        try {
            Integer.parseInt(fund.getText());
        }
        catch(NumberFormatException e){
            if(box1.isSelected()){
                if(both == onlyFund) {
                    textArea.appendText("Numeric data must be entered when entering funds\n");
                }
                else{
                    textArea.appendText("Numeric data must be entered when entering funds and credits\n");
                }
                except = true;
            }
        }
        catch(Exception e){
            if(box1.isSelected()) {
                if(both == onlyFund) {
                    textArea.appendText("Numeric data must be entered when entering funds\n");
                }
                else{
                    textArea.appendText("Numeric data must be entered when entering funds and credits\n");
                }
                except = true;
            }
        }
        return except;
    }


    /**
     * adds a student to the list of students and an event handler for the add button.
     * @param event is action being caught
     * @author craig Natoli
     */
    @FXML
    public void add(ActionEvent event){
        int credit1 = 0;
        if(fname.getText().trim().equals("") == false && lname.getText().trim().equals("") == false && credit.getText().trim().equals("") == false) {
            try {
                credit1 = Integer.parseInt(credit.getText());
                if(inState.isSelected()){
                    if (nonNumeric(onlyFund) == false) {
                        addType(credit1);
                    }
                }
                else{
                    addType(credit1);
                }
            }
            catch (NumberFormatException e){
                if(nonNumeric(fundAndCredit) == false){
                    textArea.appendText("Numeric data must be entered when entering credits\n");
                }
            }
            catch (Exception e) {
                if(nonNumeric(fundAndCredit) == false){
                    textArea.appendText("Numeric data must be entered when entering credits\n");
                }
            }
        }
        else{
            emptyFieldAdd();
        }
        clear();
    }

    /**
     * adds an instate student.
     * @param fname first name of student
     * @param lname last name of student
     * @param credit2 number of credits student is taking
     * @author Craig Natoli
     */
    private void addInstate(String fname, String lname, int credit2){
        int funds = 0;
        if(box1.isSelected()){
            funds = Integer.parseInt(fund.getText());
        }
        if (credit2 <= 0 && funds < 0) {//check if funding is less than 0 and credit less than or equal 0
            textArea.appendText("Must Enter a credit value greater than 0 and fund value greater than or equal to 0 \n");
            return;
        }
        else if (credit2 <= 0) {// check if credit less than or eqal to 0
            textArea.appendText("Must Enter a credit value greater than 0 \n");
        }
        else if (funds < 0) {//check if funding less than 0
            textArea.appendText("Must Enter a funds value equal or greater than 0\n");
        }
        else if (credit2 > 0 && funds >= 0) {// check if credit greater than 0 and funding greater than or equal to 0
            Instate inState = new Instate(fname, lname, credit2, funds);
            if (cs213.contains(inState) == false) {
                cs213.add(inState);
                textArea.appendText(fname + " " + lname + " has been added to the list\n");
            }
            else {
                textArea.appendText(fname + " " + lname + " is already in the list\n");
            }
        }
    }

    /**
     * adds out-of-state student.
     * @param fname first name of student
     * @param lname last name of student
     * @param credit1 number of credits a student is taking
     * @author Craig Natoli
     */
    private void addOutState(String fname, String lname,int credit1){
        if(credit1 <= 0){//check if credit less than or equal to 0
            textArea.appendText("Must Enter a credit value greater than 0 \n");
        }
        else{
            if(box2.isSelected()){// Is tri-state
                Outstate outState = new Outstate(fname,lname,credit1,true);
                if(cs213.contains(outState) == false){
                    cs213.add(outState);
                    textArea.appendText(fname+ " " + lname + " has been added to the list\n");
                }
                else{
                    textArea.appendText(fname+ " " + lname + " is already in the list\n");
                }
            }
            else{//Is not tri-state
                Outstate out = new Outstate(fname,lname,credit1,false);
                if(cs213.contains(out) == false){
                    cs213.add(out);
                    textArea.appendText(fname+ " " + lname + " has been added to the list\n");
                }
                else{
                    textArea.appendText(fname+ " " + lname + " is already in the list\n");
                }
            }
        }
    }

    /**
     * adds an international student.
     * @param fname first name of the student
     * @param lname last name of the student
     * @param credit1 number of credits the student is taking
     * @author Shashwat Singh
     */
    private void addInternational(String fname, String lname,int credit1){
        if(credit1 < 9){// check if credit less than 9
            textArea.appendText("International students must enter in a credit value greater than 9 \n");
        }
        else{
            if(box3.isSelected()){//Is exchange student
                International international = new International(fname,lname,credit1,true);
                if(cs213.contains(international) == false){
                    cs213.add(international);
                    textArea.appendText(fname+ " " + lname + " has been added to the list\n");
                }
                else{
                    textArea.appendText(fname+ " " + lname + " is already in the list\n");
                }
            }
            else{//Is not exchange student
                International international = new International(fname,lname,credit1,false);
                if(cs213.contains(international) == false){
                    cs213.add(international);
                    textArea.appendText(fname+ " " + lname + " has been added to the list\n");
                }
                else{
                    textArea.appendText(fname+ " " + lname + " is already in the list\n");
                }
            }
        }
    }

    /**
     * Removes a student from the list if the student exists and an event handler for the remove button.
     * @param event is action being caught
     * @author Shashwat Singh
     */
    @FXML
    public void remove(ActionEvent event){
        if(fname.getText().trim().equals("") == false && lname.getText().trim().equals("") == false) {//check if first and last name text feild is not empty
            Instate remove = new Instate(fname.getText(),lname.getText(),0,0);
            if(cs213.isEmpty() == false){//check if list is empty
                if(cs213.contains(remove) == true){// check if list contains student
                    if(cs213.remove(remove) == true){//check if student has been removed
                        textArea.appendText(fname.getText()+ " " + lname.getText() + " has been removed from the list\n");
                    }
                    else{
                        textArea.appendText(fname.getText()+ " " + lname.getText() + " has not been removed from the list\n");
                    }
                }
                else{
                    textArea.appendText(fname.getText()+ " " + lname.getText() + " is not in the list\n");
                }
            }
            else {
                textArea.appendText(fname.getText()+ " " + lname.getText()+ " is not in the list\n");
            }
            clear();
        }
        else{
            emptyFieldRemove();
            clear();
        }
    }

    /**
     * Event handler for the inState radio button.
     * @param event is action being caught
     * @author Craig Natoli
     */
    @FXML
    public void inStateRadio(ActionEvent event){
        box1.setDisable(false);
        box2.setDisable(true);
        box3.setDisable(true);
        if(box1.isSelected() == true ){// if box1 is selected enable funding text field
            fund.setDisable(false);
        }
        if(box1.isSelected() == false){
           fund.setDisable(true);
        }
        if(box2.isSelected() == true || box3.isSelected() == true){//deselecting these check boxes if they are checked
            box2.setSelected(false);
            box3.setSelected(false);
        }
    }

    /**
     * Event handler for the outState radio button.
     * @param event is action being caught
     * @author Craig Natoli
     */
    @FXML
    public void outStateRadio(ActionEvent event){
        fund.setDisable(true);
        box1.setDisable(true);
        box2.setDisable(false);
        box3.setDisable(true);
        if(box1.isSelected() == true || box3.isSelected() == true){//deselecting these check boxes if they are checked
            box1.setSelected(false);
            box3.setSelected(false);
        }
    }

    /**
     * Event handler for the international radio button.
     * @param event is action being caught
     * @author Craig Natoli
     */
    @FXML
    public void internationalRadio(ActionEvent event){
        fund.setDisable(true);
        box1.setDisable(true);
        box2.setDisable(true);
        box3.setDisable(false);
        if(box1.isSelected() == true || box2.isSelected() == true){//deselecting these check boxes if they are checked
            box1.setSelected(false);
            box2.setSelected(false);
        }
    }

    /**
     * prints all of the students currently in the list.
     * @param event is action being caught
     * @author Shashwat Singh
     */
    @FXML
    public void print(ActionEvent event){
        if(cs213.isEmpty()!= true){//checking if the list is empty
            textArea.appendText("The following students in the list\n");
            textArea.appendText(cs213.toString());
            textArea.appendText("--End of the List--\n");
        }
        else{
            textArea.appendText("There are 0 students in the list\n");
        }

    }


}
