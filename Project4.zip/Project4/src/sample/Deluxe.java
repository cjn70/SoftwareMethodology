/**
 * This class create an instance of a Deluxe pizza and calculates the price of a deluxe pizza.
 * @author Craig Natoli Shashwat Singh
 */
package sample;

public class Deluxe extends Pizza {
    private static final String SMALL = "small";
    private static final String MEDIUM = "medium";
    private static final String LARGE = "large";
    private static final int SMALLPRICE = 14;
    private static final int MEDIUMPRICE = 16;
    private static final int LARGEPRICE = 18;

    /**
     * Parametrized Constructor initializing the style and size of the pizza.
     * @param style of the pizza
     * @param size of the pizza
     * @author Shashwat Singh
     */
    public Deluxe(String style, String size){
        super(style,size);

    }

    /**
     * Calculates the price of the pizza.
     * @return price of the pizza
     * @author Shashwat Singh
     */
    @Override
    public int pizzaPrice(){
        if(super.size.equals(SMALL)){
            return SMALLPRICE;
        }
        if(super.size.equals(MEDIUM)){
            return MEDIUMPRICE;
        }
        if(super.size.equals(LARGE)){
            return LARGEPRICE;
        }
        return 0;
    }

    /**
     * Format's description of the pizza
     * @return description of the pizza
     * @author Shashwat Singh
     */
    @Override
    public String toString(){
        return super.toString() + "TOPPINGS:\nSausage\nPepperoni\nGreen Pepper\nOnion\nMushroom\n" ;
    }
}
