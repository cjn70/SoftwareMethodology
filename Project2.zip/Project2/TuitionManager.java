/**
 * This class handles the commands, adding, removing, and printing of the students
 * the user interacts with.
 * @author Craig Natoli Shashwat Singh
 */
import java.util.Scanner;
public class TuitionManager {
    Scanner stdin;
    StudentList cs213;

    /**
     * handles the commands via a switch case inorder to know what to add, remove, or
     * detect bad commands.
     * @author Shashwat Singh
     */
    public void run()
    {
        stdin = new Scanner(System.in);
        cs213 = new StudentList();
        boolean done = false;
        //variable to store returned array
        System.out.println("Let's start a List of Students!");
        while (!done)
        {
            String command = stdin.next();
            switch(command.charAt(0))
            {
                case 'I':
                    addInstate(stdin.next(),stdin.next(),Integer.parseInt(stdin.next()),Integer.parseInt(stdin.next()));
                    break;
                case 'O':
                    addOutState(stdin.next(),stdin.next(),Integer.parseInt(stdin.next()),stdin.next());
                    break;
                case 'N':
                    addInternational(stdin.next(),stdin.next(),Integer.parseInt(stdin.next()),stdin.next());
                    break;
                case 'R':
                    remove(stdin.next(),stdin.next());
                    break;
                case 'P':
                    print();
                    break;
                case 'Q':
                    done = true;
                    break;
                default:
                    System.out.println("command " + "'"+ command.charAt(0)+ "'" + " is not supported!");
                    stdin.nextLine();
            }

        }
        System.out.println("Program Terminated");
    } //run()
    /**
     * adds an instance of an instate object to the students list.
     * @param fname first name of the student
     * @param lname last name of the student
     * @param credit number of credits the student is taking
     * @param fund the amount of funding the student will receive
     * @author Shashwat Singh
     */
    private void addInstate(String fname, String lname, int credit, int fund){
        Instate instate = new Instate(fname,lname,credit,fund);
        if(credit < 12 && credit > 0 && fund >=0){//checking if the student has less than 12 credits and more than 0 funding
            if(cs213.contains(instate) == false){//checking if the student already exists
                System.out.println(fname + " " + lname + " " + "has been added to the list");
                cs213.add(instate);
            }
            else{
                System.out.println(fname + " " + lname + " " + " is already in the list");
            }
        }
        if(credit >= 12 && fund >= 0){//checking if the student has at least 12 credits and at least 0 funding
            if(cs213.contains(instate) == false){//checking if the student already exists
                System.out.println(fname + " " + lname + " " + "has been added to the list");
                cs213.add(instate);
            }
            else{
                System.out.println(fname + " " + lname + " " + " is already in the list");
            }
        }
        if(credit <= 0 && fund < 0){// checking if the student has less than or 0 credits and 0 funding
            System.out.println(fname + " " + lname + " " + "did not enter in enough credits and funds");
            return;
        }
        if(credit <= 0 ){//checking if the student has less than or 0 credits
            System.out.println(fname + " " + lname + " " + "did not enter in enough credits");
        }
        if(fund < 0){//checking if the student has less than 0 funding
            System.out.println(fname + " " + lname + " " + "did not enter in enough funds");
        }
    }

    /**
     * adds an instance of an out of state object to the students list.
     * @param fname first name of the student
     * @param lname last name of the student
     * @param credit number of credits the student is taking
     * @param status tri-state student or not
     * @author Shashwat Singh
     */
    private void addOutState(String fname, String lname, int credit, String status){
        Outstate outstate = new Outstate(fname,lname,credit, status.equals("T"));
        if(credit > 0){//checking if the student entered in enough credits
            if(cs213.contains(outstate) == false){//checking if the student already exists
                cs213.add(outstate);
                System.out.println(fname + " " + lname + " " + "has been added to the list");
            }
            else{
              System.out.println(fname + " " + lname + " " +  " is already in the list");
            }
        }
        else{
            System.out.println(fname + " " + lname + " " + "did not enter in enough credits");
        }
    }

    /**
     * adds an instance of an international object to the students list.
     * @param fname first name of the student
     * @param lname last name of the student
     * @param credit number of credits the student is taking
     * @param status exchange student or not
     * @author Shashwat Singh
     */
    private void addInternational(String fname, String lname, int credit, String status){
        International international = new International(fname,lname,credit, status.equals("T"));
        if(credit >= 9){//checking that the student entered in at least 9 credits
            if(cs213.contains(international) == false){//checking that the student does not already exist
                cs213.add(international);
                System.out.println(fname + " " + lname + " " + "has been added to the list");
            }
            else{
                System.out.println(fname + " " + lname + " " +  " is already in the list");
            }
        }
        else {
            System.out.println(fname + " " + lname + " " + "did not enter in enough credits");
        }
    }

    /**
     * Removes a student from the list.
     * @param fname first name of the student
     * @param lname last name of the student
     * @author Shashwat Singh
     */
    private void remove(String fname, String lname){
        Instate remove = new Instate(fname,lname,0,0);
        if(cs213.isEmpty() != true){//checking if the list is empty
            if(cs213.contains(remove) == true){//checking if the student is in the list
                if(cs213.remove(remove) == true) {//checking if the student has been removed
                    System.out.println(fname + " " + lname + " has been removed from the list");
                }
                else{
                    System.out.println(fname + " " + lname + " has not been removed from the list");
                }
            }
            else{
                System.out.println(fname + " " + lname + " " +  " is not in the list");
            }
        }
        else{
            System.out.println(fname + " " + lname + " " +  " is not in the list");
        }
    }

    /**
     * Prints the contents of the student list.
     * @author Shashwat Singh
     */
    private void print(){
        if(cs213.isEmpty()!= true) {//checking if the list is empty
            System.out.println("The following students in the list");
            cs213.print();
            System.out.println("--End of the List--");
        }
        else{
            System.out.println("There are 0 students in the list");
        }
    }

    /**
     * The driver that creates an instance of TuitionManager to run.
     * @param args arguments from command line
     * @author Shashwat Singh
     */
    public static void main(String args[]){
        new TuitionManager().run();
    }
}
