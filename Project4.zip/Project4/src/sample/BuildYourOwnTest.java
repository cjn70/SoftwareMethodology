/**
 * This is the JUnit test class that performs black box testing on the BuildYourOwn class.
 * @author Craig Natoli Shashwat Singh
 */
package sample;

import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.*;

class BuildYourOwnTest {
    /**
     * Tests the varying inputs build your own pizza can have getting varying prices.
     * @author Craig Natoli
     */
    @Test
    public void pizzaPrice() {
        ArrayList<String> toppings = new ArrayList<String>();
        toppings.add("Mushroom");
        BuildYourOwn pizza1 = new BuildYourOwn("Build Your Own","small",toppings);
        //Testing pizzaPrice with 1 toppings
        assertEquals( 7,pizza1.pizzaPrice(), 0);
        toppings.add("Beef");
        pizza1 = new BuildYourOwn("Build Your Own","small",toppings);
        //Testing pizzaPrice with 2 toppings
        assertEquals( 9,pizza1.pizzaPrice(), 0);
        toppings.add("Chicken");
        pizza1 = new BuildYourOwn("Build Your Own","small",toppings);
        //Testing pizzaPrice with 3 toppings
        assertEquals( 11,pizza1.pizzaPrice(), 0);
        toppings.add("Ham");
        pizza1 = new BuildYourOwn("Build Your Own","small",toppings);
        //Testing pizzaPrice with 4 toppings
        assertEquals( 13,pizza1.pizzaPrice(), 0);
        toppings.add("Mushroom");
        pizza1 = new BuildYourOwn("Build Your Own","small",toppings);
        //Testing pizzaPrice with 5 toppings
        assertEquals( 15,pizza1.pizzaPrice(), 0);
        toppings.add("Onion");
        pizza1 = new BuildYourOwn("Build Your Own","small",toppings);
        //Testing pizzaPrice with 5 toppings
        assertEquals( 17,pizza1.pizzaPrice(), 0);
        toppings.add("Sausage");
        pizza1 = new BuildYourOwn("Build Your Own","small",toppings);
        //Testing pizzaPrice with 5 toppings
        assertEquals( 19,pizza1.pizzaPrice(), 0);

        //Testing Medium Pizzas
        ArrayList<String> toppings2 = new ArrayList<String>();
        toppings2.add("Mushroom");
        pizza1 = new BuildYourOwn("Build Your Own","medium",toppings2);
        //Testing pizzaPrice with 1 toppings
        assertEquals( 9,pizza1.pizzaPrice(), 0);
        toppings2.add("Beef");
        pizza1 = new BuildYourOwn("Build Your Own","medium",toppings2);
        //Testing pizzaPrice with 2 toppings
        assertEquals( 11,pizza1.pizzaPrice(), 0);
        toppings2.add("Chicken");
        pizza1 = new BuildYourOwn("Build Your Own","medium",toppings2);
        //Testing pizzaPrice with 3 toppings
        assertEquals( 13,pizza1.pizzaPrice(), 0);
        toppings2.add("Ham");
        pizza1 = new BuildYourOwn("Build Your Own","medium",toppings2);
        //Testing pizzaPrice with 4 toppings
        assertEquals( 15,pizza1.pizzaPrice(), 0);
        toppings2.add("Mushroom");
        pizza1 = new BuildYourOwn("Build Your Own","medium",toppings2);
        //Testing pizzaPrice with 5 toppings
        assertEquals( 17,pizza1.pizzaPrice(), 0);
        toppings2.add("Onion");
        pizza1 = new BuildYourOwn("Build Your Own","medium",toppings2);
        //Testing pizzaPrice with 5 toppings
        assertEquals( 19,pizza1.pizzaPrice(), 0);
        toppings2.add("Sausage");
        pizza1 = new BuildYourOwn("Build Your Own","medium",toppings2);
        //Testing pizzaPrice with 6 toppings
        assertEquals( 21,pizza1.pizzaPrice(), 0);

        //Testing Large Pizzas
        ArrayList<String> toppings3 = new ArrayList<String>();
        toppings3.add("Mushroom");
        pizza1 = new BuildYourOwn("Build Your Own","large",toppings3);
        //Testing pizzaPrice with 1 toppings
        assertEquals( 11,pizza1.pizzaPrice(), 0);
        toppings3.add("Beef");
        pizza1 = new BuildYourOwn("Build Your Own","large",toppings3);
        //Testing pizzaPrice with 2 toppings
        assertEquals( 13,pizza1.pizzaPrice(), 0);
        toppings3.add("Chicken");
        pizza1 = new BuildYourOwn("Build Your Own","large",toppings3);
        //Testing pizzaPrice with 3 toppings
        assertEquals( 15,pizza1.pizzaPrice(), 0);
        toppings3.add("Ham");
        pizza1 = new BuildYourOwn("Build Your Own","large",toppings3);
        //Testing pizzaPrice with 4 toppings
        assertEquals( 17,pizza1.pizzaPrice(), 0);
        toppings3.add("Mushroom");
        pizza1 = new BuildYourOwn("Build Your Own","large",toppings3);
        //Testing pizzaPrice with 5 toppings
        assertEquals( 19,pizza1.pizzaPrice(), 0);
        toppings3.add("Onion");
        pizza1 = new BuildYourOwn("Build Your Own","large",toppings3);
        //Testing pizzaPrice with 5 toppings
        assertEquals( 21,pizza1.pizzaPrice(), 0);
        toppings3.add("Sausage");
        pizza1 = new BuildYourOwn("Build Your Own","large",toppings3);
        //Testing pizzaPrice with 6 toppings
        assertEquals( 23,pizza1.pizzaPrice(), 0);
    }
}