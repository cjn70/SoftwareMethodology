/**
  This class adds, prints, and removes team members from the array.
 @author Craig Natoli Shashwat Singh
 */
public class Team 
{
   private final int NOT_FOUND = -1;
   private final int GROW_SIZE = 4; //initial and grow size
   private TeamMember [] team;
   private int numMembers;

   /**
    * Default constructor, that initalizes the TeamMember array,
    * and the integer numMembers
    * @author Craig Natoli
    */
   public Team()
   {
      team = new TeamMember[GROW_SIZE];
      numMembers = 0;
   }

   /**
    * Finds the location of the team members entered.
    * @param m instance of TeamMember to a find
    * @return foundMember >=0 if team member was found otherwise -1
    * @author Craig Natoli
    */
   private int find(TeamMember m)
   {
      int i = 0;
      int foundMember = 0;
      int length = team.length;
      for(i = 0; i < length; i++){
            if(team[i] != null){
               if(team[i].equals(m) == true){
                  foundMember = i;
                  break;
               }
               else{
                  foundMember = -1;
               }
            }
         }
      return foundMember;
   }//find()

   /**
    * Dynamically increases the team array.
    * @author Craig Natoli
    */
   private void grow()
   {
         int i = 0;
         TeamMember temp[] = null;
         if((numMembers+1) > team.length) {// only increase the array when thier are no spaces left.
            temp = new TeamMember[team.length + GROW_SIZE];
            for (i = 0; i < team.length; i++) {
               temp[i] = team[i];
            }
            team = temp;
         }
   }//grow()

   /**
    * Checks to see if the team array is empty.
    * @return true if the list of team members is empty
    * @author Craig Natoli
    */
   public boolean isEmpty()
   {
      int i = 0;
      int ZEROMEMBERS = 0;
      if(numMembers > ZEROMEMBERS ){
         if(team[0] == null ){
           return true; 
         }
         else{
            return false;
         }
      }
      else{
         return true;
      }
   }//isEmpty()

   /**
    * Adds a person the team array.
    * @param m instance of TeamMember to add ot the list.
    * @author Craig Natoli
    */
   public void add(TeamMember m)
   {
            int ZEROMEMBERS = 0;
            grow();
            numMembers ++;
            if(numMembers == ZEROMEMBERS ){
               team[0] = m;
            }
            else{
               team[(numMembers-1)] = m;
            }
   }//add()

   /**
    * Sets team member removed to null and inserts last team member in the index that was removed.
    * @param memberNum is the number of members still in the team
    * @param m instance of TeamMember to set null for removal
    * @author Craig Natoli
    */
   private void moveIndex(int memberNum, TeamMember m){
      TeamMember temp[] = null;
      int TEMPMEMBER = 1;
      temp = new TeamMember[TEMPMEMBER];
      int ZEROMEMBERS = 0;
      int location = find(m);
      if(memberNum != ZEROMEMBERS ){//insert member at end of array
         team[location] = null;
         temp[0] = team[numMembers-1];
         team[location] = temp[0];
         team[numMembers-1] = null;
      }
      if(memberNum == ZEROMEMBERS ){//insert members at index 0 if array is empty
         team[location] = null;
         temp[0] = team[0];
         team[location] = temp[0];
         team[numMembers-1] = null;
      }      
   }//moveIndex()

   /**
    * Removes the team member from the array.
    * @param m of a TeamMember instance to remove
    * @return true if the team member was removed
    * @author Craig Natoli
    */
   public boolean remove(TeamMember m)
   {
      int ZEROMEMBERS = 0;
      int location = find(m);
      if(numMembers != ZEROMEMBERS){
         if(location != NOT_FOUND){
               moveIndex(numMembers,m);
               if(numMembers != ZEROMEMBERS){
                  numMembers -- ;
                  return true;
               }
               else{
                  return true;
               }
         }     
      }
       else{
            moveIndex(numMembers,m);
            return true;
         }
       return false;
   }//remove()

   /**
    * Checks to see if the team member already exists in the array.
    * @param m of a TeamMember instance to check
    * @return true if the team member exists
    * @author Craig Natoli
    */
   public boolean contains(TeamMember m)
   {
      int i = 0;
      int ZEROMEMBERS = 0;
      if(numMembers == ZEROMEMBERS){
         return false;
      }
      int length = team.length;
      for(i = 0; i < length; i++){
         if(team[i] != null){
            if(team[i].equals(m) == true){
               return true;
            }
         }
      }
      return false;
   }//contains()

   /**
    * Prints out all of the team members.
    * @author Craig Natoli
    */
   public void print()
   {
      int i = 0;
      for(i = 0; i < numMembers; i++){
         System.out.println(team[i]);
      }
   } //print()
}//Team
