/**
   This class handles the commands, adding, removing, and printing of the team members
   the user interacts with.
 @author Craig Natoli Shashwat Singh
 */
import java.util.Scanner;
public class ProjectManager {
   Scanner stdin;
   Team cs213;

   /**
    * Calls the correct method that corresponds with the command or error by using a switch statement
    * @author Craig Natoli
    */
   public void run()
   {
      stdin = new Scanner(System.in);
      cs213 = new Team();
      String word = "";
      String date = "";
      boolean done = false;
      //variable to store returned array  
      System.out.println("Let's start a new team!");
      while ( !done )
      {
         String command = stdin.next();
         switch(command.charAt(0))  
         {   
            case 'A':
               word = stdin.next();
               date = stdin.next();
               add(word,date);
		         break; 
            case 'R':
               word = stdin.next();
               date = stdin.next();
               remove(word,date);
               break;
            case 'P':
               print();
               break;
            case 'Q':
               done = true;
               break;
            default:
            System.out.println("command " + "'"+ command.charAt(0)+ "'" + " is not supported!");
            stdin.nextLine();
         }  
         
      }
      System.out.println("The team is ready to go!");
      //write java code before you terminate the program
   } //run()
   /**
    * Adds members to the team if the member entered passes a series of conditions.
    * @param word String is hold name of team member.
    * @param date String is hold date of team member.
    * @author Craig Natoli
    */
   private void add(String word, String date){
      Date date1 = new Date(date);
      TeamMember member = new TeamMember (word,date1);
      if(date1.isValid() == true){//checking if date is valid
         if(cs213.isEmpty() != true){//checking if array is empty
            if(cs213.contains(member) != true){//checking if member already exists
               cs213.add(member);
               System.out.println(member + " has joined the team");              
            }
            else{
               System.out.println(member + " is already in the team");
            }
         }
         else{
            cs213.add(member);
            System.out.println(member + " has joined the team");            
         }
      }
      else{
         System.out.println(date1 + " is not a valid date!");         
      }
   }//add()

   /**
    * removes a member from the team if the member entered passes a series of conditions.
    * @param word String is hold name of team member.
    * @param date String is hold date of team member.
    * @author Craig Natoli
    */
   private void remove(String word, String date)
   {
      Date date1 = new Date(date);
      TeamMember member = new TeamMember (word,date1);
         if(date1.isValid() == true){//checking if date is valid
            if(cs213.isEmpty() != true){//checking if array is empty
               if(cs213.contains(member) == true){//checking if array contains member
                  if(cs213.remove(member) == true){//checking if member was removed
                     System.out.println(member + " has left the team.");
                  }
                  else{
                     System.out.println(member + " has not left the team.");
                  }
               }
               else{
                     System.out.println(member + " is not a team member.");
               }
            }
            else{
               System.out.println(member + " is not a team member.");
            }
         }
         else{
            System.out.println(date1 + " is not a valid date!");          
         }
   }//remove

   /**
    * Prints out all of the members on the team.
    * @author Craig Natoli
    */
   private void print()
   {
         if(cs213.isEmpty() != true){
            System.out.println("We have the following members: ");
            cs213.print();
            System.out.println("-- end of the list --");
         }
         else {
             System.out.println("We have 0 team members!");
         }

   }//print()
} //ProjectManager
