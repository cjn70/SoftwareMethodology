/**
 * This class is the second activity that handles displaying the correct advice to be given to the
 * corresponding BMI calculated.
 * @author Craig Natoli Shashwat Singh
 */
package com.example.bmi_project5;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.bmi_project5.R;

public class Activity2 extends AppCompatActivity {
    Button button1;
    String message;
    double bmi;
    TextView textView1;
    ImageView imageView1;
    private static final double underweight = 18.5;
    private static final double normal = 25;
    private static final double overweight = 30;
    private static final double obese = 29.9;
    /**
     * This method is used to initialize the activity
     * @param savedInstanceState opportunity to save any application state that you want to restore
     * when the user returns to your application
     * @author Shashwat Singh
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        Intent intent = getIntent();
        message = intent.getStringExtra(MainActivity.EXTRA_MESSAGE);
        bmi = Double.parseDouble(message);
        button1 = (Button) findViewById(R.id.button1);
        textView1 = (TextView) findViewById(R.id.textView1);
        imageView1 = (ImageView) findViewById(R.id.imageView1);
        adviceType(bmi);
        setTitle("Advice based on the BMI");
    }
    /**
     * Helper method that displays the correct advice and image the corresponds to the bmi
     * @param bmi of the height and weight
     * @author Shashwat Singh
     */
    @SuppressLint("SetTextI18n")
    private void adviceType(double bmi){
        if(bmi < underweight){//Everything less than 18.5 BMI
            textView1.setText("Underweight");
            imageView1.setImageResource(R.drawable.underweight);
        }
        else if(bmi < normal){//Everything less than 25 BMI
            textView1.setText("Normal");
            imageView1.setImageResource(R.drawable.normal);
        }
        else if(bmi < overweight){//Everything less than 30 BMI
            textView1.setText("Overweight");
            imageView1.setImageResource(R.drawable.overweight);
        }
        else if (bmi > obese ){//Everything greater than 30 BMI
            textView1.setText("Obese");
            imageView1.setImageResource(R.drawable.obese);
        }
    }
    /**
     * Destroys the activity and returns to the main activity
     * @param view distinguishes which view on the layout has been selected
     * @author Shashwat Singh
     */
    public void onButtonClickedGoBack(View view) {
        finish();
    }
}
